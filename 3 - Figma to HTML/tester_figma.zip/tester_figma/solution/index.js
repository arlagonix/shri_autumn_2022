/**
 * Если нет идей, загляните в папку ./example
 * В файле solution.js будет пример превращения компонента Text в HTML.
 */
module.exports = function(json) {
    /**
     * Здесь будет ваше решение
     */
}